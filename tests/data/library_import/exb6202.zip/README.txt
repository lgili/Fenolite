SPDX-License-Identifier: CC0-1.0
Authored for Fenolite. https://example.invalid/exb6202

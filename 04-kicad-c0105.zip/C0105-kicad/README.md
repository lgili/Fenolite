# c0105 1.4 — perfis de impedância salvos pelo KiCad 10.0.6 (interface gráfica)

1. Copie esta pasta e abra `bench.kicad_pro` no KiCad **10.0.6**, depois o PCB `bench.kicad_pcb`.
2. Board Setup » (Design Rules ») **Tuning Profiles** (perfis de afinação/impedância). Crie:
   - um perfil **single-ended** chamado `SE50`, 50 Ω, linhas: `F.Cu` com referência `In1.Cu`, largura 0,35 mm;
     `B.Cu` com referência `In2.Cu`, largura 0,35 mm;
   - um perfil **diferencial** chamado `USB90`, 90 Ω, linha: `F.Cu` com referência `In1.Cu`, largura
     0,2 mm, gap 0,15 mm.
3. Em Net Classes, ligue a classe `SE50` ao perfil `SE50` e a classe `USB90` ao perfil `USB90`.
4. OK, salve o projeto (Ctrl+S) e me mande **só o `bench.kicad_pro` salvo**.

Se algum nome de menu for diferente na sua versão, me diga o caminho que usou.

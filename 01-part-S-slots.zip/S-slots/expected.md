# Part S: expected values

## `regions/slots.PcbDoc`

| item | X mm | Y mm | size | rotation |
|---|---|---|---|---|
| free pad, not plated | 27.000 | 7.000 | slot 12.000 × 2.000 mm, hole shape Slot | 30.000° |
| free pad, not plated | 38.000 | 13.000 | slot 10.000 × 2.000 mm, hole shape Slot | 0.000° |
| free pad, not plated | 43.000 | 8.000 | slot 10.000 × 2.000 mm, hole shape Slot | 90.000° |
| free pad, not plated | 52.000 | 8.000 | round hole 3.200 mm | 0.000° |
| board cut-out region, 132 vertices | 8.000 … 20.000 | 8.000 … 16.000 | | |
| board cut-out region, 130 vertices | 9.670 … 20.330 | 26.500 … 33.500 | | |
| board cut-out region, 164 vertices | 34.000 … 46.000 | 19.000 … 31.000 | | |

## `clearance/slots.PcbDoc`

| item | X mm | Y mm | size | rotation |
|---|---|---|---|---|
| free pad, not plated | 27.000 | 7.000 | slot 12.000 × 2.000 mm, hole shape Slot | 30.000° |
| free pad, not plated | 38.000 | 13.000 | slot 10.000 × 2.000 mm, hole shape Slot | 0.000° |
| free pad, not plated | 43.000 | 8.000 | slot 10.000 × 2.000 mm, hole shape Slot | 90.000° |
| free pad, not plated | 52.000 | 8.000 | round hole 3.200 mm | 0.000° |
| board cut-out region, 132 vertices | 8.000 … 20.000 | 8.000 … 16.000 | | |
| board cut-out region, 130 vertices | 9.670 … 20.330 | 26.500 … 33.500 | | |
| board cut-out region, 164 vertices | 34.000 … 46.000 | 19.000 … 31.000 | | |

## `gate-off/slots.PcbDoc`

| item | X mm | Y mm | size | rotation |
|---|---|---|---|---|
| free pad, not plated | 27.000 | 7.000 | slot 12.000 × 2.000 mm, hole shape Slot | 30.000° |
| free pad, not plated | 38.000 | 13.000 | slot 10.000 × 2.000 mm, hole shape Slot | 0.000° |
| free pad, not plated | 43.000 | 8.000 | slot 10.000 × 2.000 mm, hole shape Slot | 90.000° |
| free pad, not plated | 52.000 | 8.000 | round hole 3.200 mm | 0.000° |

The test points of `clearance/`: `TP1` at X 38.000, Y 28.300 mm (0.2 mm below the edge of the
milled slot S2), `TP2` at X 36.000, Y 14.700 mm (0.2 mm above the edge of the drilled slot D2),
both 1 mm round on the Top Layer, net `GND`.

# Fenolite – kit F0: documentos Draftsman (observação)

Mudança c0172 do Fenolite. Nada aqui é verificado ainda: os arquivos que você salvar mostram ao Fenolite
como o Altium Designer 26.5 grava um documento Draftsman (`.PCBDwf`). Nenhum arquivo salvo pelo Altium
entra no repositório; só contagens e nomes de elementos.

## O que tem nesta pasta

- `blink_routed/`: projeto Altium gerado pelo Fenolite (`examples/blink_routed/design.py`): placa de
  50 × 30 mm, duas camadas, `U1` e `R1` em cima, `D1` embaixo, quatro trilhas, vias e um output job.
- `SHA256SUMS`: o SHA-256 de cada arquivo, como gerado.

## Antes de começar

- Trabalhe numa cópia desta pasta.
- Todo documento novo: **File » New » Draftsman Document**, template `[Default]`, projeto
  `blink_routed.PrjPcb`, documento fonte `blink_routed.PcbDoc`.
- Salve cada arquivo com **File » Save As** dentro de `blink_routed/`, com o nome indicado.
- Faça o F0.12 por último: ele move uma peça na placa.
- Em cada passo anote `como esperado` ou a mensagem que o Altium mostrou.

## Passos

1. **F0.1** Abra `blink_routed/blink_routed.PrjPcb`. Crie um documento novo e não coloque nada. Salve como
   `F0-01.PCBDwf`. Esperado: uma folha A4 vazia, salva sem mensagem.
2. **F0.2** Feche `F0-01.PCBDwf`, abra de novo e salve sem mudar nada como `F0-02.PCBDwf`. Esperado: salvo
   sem mensagem.
3. **F0.3** Abra `F0-01.PCBDwf`, coloque um Text (**Place » Text**) com `FENOLITE-1` em qualquer lugar da
   folha. Salve como `F0-03.PCBDwf`. Esperado: o texto aparece na folha.
4. **F0.4** Abra `F0-03.PCBDwf`, troque o texto por `FENOLITE-22`. Salve como `F0-04.PCBDwf`. Esperado: o
   texto novo aparece.
5. **F0.5** Abra `F0-01.PCBDwf`, coloque uma **Board Assembly View** com View Side Top. Salve como
   `F0-05.PCBDwf`. Esperado: a vista mostra o contorno, `U1` e `R1`.
6. **F0.6** Abra `F0-05.PCBDwf`, coloque uma segunda Board Assembly View com View Side Bottom. Salve como
   `F0-06.PCBDwf`. Esperado: a segunda vista mostra `D1`, visto por baixo.
7. **F0.7** Abra `F0-01.PCBDwf`, coloque uma **Drill Drawing View** (par de camadas Top – Bottom) e uma
   **Drill Table**. Salve como `F0-07.PCBDwf`. Esperado: a vista mostra os furos com símbolos e a tabela
   lista os diâmetros.
8. **F0.8** Abra `F0-01.PCBDwf`, coloque uma **Layer Stack Legend**. Salve como `F0-08.PCBDwf`. Esperado:
   a legenda mostra as camadas da placa, duas de cobre.
9. **F0.9** Abra `F0-05.PCBDwf`, coloque uma tabela **Bill of Materials**. Salve como `F0-09.PCBDwf`.
   Esperado: a tabela lista `D1`, `R1` e `U1`.
10. **F0.10** Abra `F0-07.PCBDwf`, coloque uma **Note** com duas entradas, `FENOLITE NOTE ONE` e
    `FENOLITE NOTE TWO`, e uma **Linear Dimension** entre a borda esquerda e a direita do contorno na
    vista de furação. Salve como `F0-10.PCBDwf`. Esperado: a nota numerada 1 e 2 e a cota com a largura
    da placa, 50 mm (1968,5 mil).
11. **F0.11** Abra `F0-01.PCBDwf`, acrescente uma segunda folha. Salve como `F0-11.PCBDwf`. Esperado: duas
    folhas vazias.
12. **F0.12** (por último) Abra `blink_routed.PcbDoc`, mova `R1` 5 mm para a direita e salve o PCB. Abra
    `F0-05.PCBDwf` e rode **Tools » Import Changes From blink_routed.PcbDoc**. Salve como `F0-12.PCBDwf`.
    Esperado: a vista mostra `R1` no lugar novo.
13. **F0.13** Abra `F0-10.PCBDwf` e salve com **File » Save As**, tipo template de documento Draftsman,
    como `F0-13.DwfDot`. Esperado: salvo sem mensagem.
14. **F0.14** Abra `F0-10.PCBDwf`, **File » Export to PDF** (um arquivo, todas as folhas) como
    `F0-14.pdf`. Esperado: um PDF de uma página com as vistas, a tabela, a nota e a cota.

## O que mandar de volta

1. A pasta inteira, compactada, com os arquivos que o Altium salvou e o projeto como o Altium deixou.
2. A versão do Altium Designer (**Help » About**, no formato `AD 26.5`) e a data.
3. Um resultado por passo: `como esperado` ou a mensagem que apareceu.

O Fenolite só lê os arquivos depois de rodar a verificação de caminhos do `fenolite kit verify` na pasta.
